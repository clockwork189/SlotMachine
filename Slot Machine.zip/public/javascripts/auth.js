var facebookAuth = function () {
    window.open("/auth/facebook", "FacebookAuth", "status=1, height=450, width=500, resizable=0");
};
var twitterAuth = function () {
    window.open("/auth/twitter", "TwitterAuth", "status=1, height=450, width=500, resizable=0");
};
var googleAuth = function () {
    window.open("/auth/google", "GoogleAuth", "status=1, height=450,  width=500, resizable=0");
};